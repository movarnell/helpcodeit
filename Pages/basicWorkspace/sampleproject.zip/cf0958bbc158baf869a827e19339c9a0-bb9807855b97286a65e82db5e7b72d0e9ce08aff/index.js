// Your javascript can go here, to view it you will open the index.html file in your browser
// You can also use the console in your browser to view the output of your code by right clicking and selecting inspect
// or by pressing F12 on your keyboard and selecting the console tab
// You can also use console.log() to output to the console
// provided is an example of how to use console.log().

console.log("Hello World"); // You can delete this line if you want it is just a demo of console.log()
